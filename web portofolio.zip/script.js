document.getElementById('whatsapp-btn').addEventListener('click', function() {
    let phone = '6285840351569'; // Ganti dengan nomor tujuan
    window.location.href = `https://wa.me/${phone}`;
});

